export type Product = {
  id: string;
  category: string;
  categorySlug: string;
  title: string;
  composition?: string;
  weights: { weight: string; price: number }[];
  emoji?: string;
  image?: string;
  badge?: 'hit' | 'new';
  isLean?: boolean;
};

export const CATEGORIES = [
  { slug: 'ossetian', title: 'Осетинские пироги' },
  { slug: 'meat', title: 'Мясные пироги' },
  { slug: 'sweet', title: 'Сладкие пироги' },
];

export const MENU: Product[] = [
  {
    id: '1',
    category: 'Осетинские пироги',
    categorySlug: 'ossetian',
    title: 'Фыдджын (мясной)',
    composition: 'Говядина, лук, специи',
    weights: [{ weight: '1000 г', price: 1290 }, { weight: '1200 г', price: 1590 }],
    emoji: '🥩',
    badge: 'hit'
  },
  {
    id: '2',
    category: 'Осетинские пироги',
    categorySlug: 'ossetian',
    title: 'Цахараджын',
    composition: 'Осетинский сыр, свекольные листья',
    weights: [{ weight: '1000 г', price: 1120 }],
    emoji: '🍃',
    badge: 'hit'
  },
  {
    id: '3',
    category: 'Мясные пироги',
    categorySlug: 'meat',
    title: 'Пирог с курицей и сыром',
    composition: 'Куриное филе, осетинский сыр',
    weights: [{ weight: '1000 г', price: 1150 }],
    emoji: '🍗'
  },
  {
    id: '4',
    category: 'Мясные пироги',
    categorySlug: 'meat',
    title: 'Пирог с говядиной и грибами',
    composition: 'Говядина, шампиньоны',
    weights: [{ weight: '1000 г', price: 1350 }],
    emoji: '🍄'
  },
  {
    id: '5',
    category: 'Сладкие пироги',
    categorySlug: 'sweet',
    title: 'Пирог с вишней',
    composition: 'Вишня, сахар',
    weights: [{ weight: '1000 г', price: 950 }],
    emoji: '🍒'
  },
  {
    id: '6',
    category: 'Сладкие пироги',
    categorySlug: 'sweet',
    title: 'Пирог с яблоком и корицей',
    composition: 'Яблоки, корица',
    weights: [{ weight: '1000 г', price: 900 }],
    emoji: '🍏'
  },
  {
    id: '7',
    category: 'Осетинские пироги',
    categorySlug: 'ossetian',
    title: 'Уалибах (с сыром)',
    composition: 'Осетинский сыр',
    weights: [{ weight: '1000 г', price: 1050 }],
    emoji: '🧀',
    badge: 'hit'
  },
  {
    id: '8',
    category: 'Осетинские пироги',
    categorySlug: 'ossetian',
    title: 'Картофджын',
    composition: 'Осетинский сыр, картофель',
    weights: [{ weight: '1000 г', price: 900 }],
    emoji: '🥔'
  }
];

export const minPrice = 1500;
