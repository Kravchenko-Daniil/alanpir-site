import ProductCard from '@/components/ProductCard';

const CATEGORIES = ['Все', 'Новинки', 'Хиты', 'Мясные', 'Сырные', 'Постные', 'Сладкие'];

export default function CatalogPage() {
  return (
    <div className="py-6 sm:py-10">
      <h1 className="text-3xl sm:text-4xl md:text-5xl mb-6 sm:mb-8 text-ink font-serif font-bold tracking-tight">Все пироги и сеты</h1>
      
      {/* Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4 mb-6 sm:mb-8 sticky top-[72px] sm:top-20 md:top-[96px] bg-bg-warm/95 backdrop-blur-md py-3 z-40 -mx-4 px-4 sm:mx-0 sm:px-0">
        <div className="flex overflow-x-auto pb-2 gap-2 no-scrollbar">
          {CATEGORIES.map((cat, i) => (
            <button 
              key={cat}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-colors shrink-0 ${
                i === 0 
                  ? 'bg-ink text-white' 
                  : 'bg-surface text-ink hover:bg-border-warm shadow-sm border border-border-warm'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 mt-2 md:mt-0 pb-2 md:pb-0">
          <label className="flex items-center gap-2 cursor-pointer text-xs sm:text-sm font-bold text-ink bg-surface px-4 py-2 rounded-full border border-border-warm shadow-sm">
            <div className="relative">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-8 h-5 bg-border-warm peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-terracotta"></div>
            </div>
            Только постные
          </label>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
        <ProductCard 
          title="Фыдджын (мясной)"
          weight="1000 г • Тонкое тесто"
          price={1290}
          imageEmoji="🥩"
          badge={{ text: 'Хит', type: 'hit' }}
        />
        <ProductCard 
          title="Цахараджын"
          weight="1000 г • Сыр и листья свеклы"
          price={1120}
          imageEmoji="🍃"
        />
        <ProductCard 
          title="Пирог с сёмгой"
          weight="700 г • Шпинат и рыба"
          price={1740}
          imageEmoji="🐟"
          badge={{ text: 'Новинка', type: 'new' }}
        />
        <ProductCard 
          title="Уалибах (сырный)"
          weight="1000 г • Осетинский сыр"
          price={1120}
          imageEmoji="🧀"
        />
        <ProductCard 
          title="Картофджын"
          weight="1000 г • Картофель и сыр"
          price={990}
          imageEmoji="🥔"
        />
        <ProductCard 
          title="Фыдджын мини"
          weight="600 г • Тонкое тесто"
          price={1020}
          imageEmoji="🥩"
        />
      </div>
    </div>
  );
}
